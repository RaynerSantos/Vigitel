def gerar_relatorio_elegibilidade(df, tipo, total_teorico):
    # Normaliza colunas
    df.columns = df.columns.str.upper()
    df['TIPO_MUNICIPIO'] = df['TIPO_MUNICIPIO'].str.upper()
    df['ESTADO'] = df['ESTADO'].str.upper()

    # Define colunas de status
    status_elegiveis = [20, 5, 6, 4, 44, 66, 8, 9, 10, 88]
    status_nao_elegiveis = [1, 2, 3, 7, 22, 33]

    # Lista de réplicas (fixo: 1-50, celular: 1-120)
    num_replicas = 50 if tipo == 'FIXO' else 120
    total_por_replica = 400 if tipo == 'FIXO' else 500

    # Estrutura de escrita
    output_path = f"/mnt/data/Relatório_Elegíveis_{tipo.capitalize()}.xlsx"
    writer = pd.ExcelWriter(output_path, engine='xlsxwriter')
    workbook = writer.book

    for municipio in ['CAPITAL', 'INTERIOR']:
        aba_df = df[df['TIPO_MUNICIPIO'] == municipio]
        sheet_name = municipio
        worksheet_format = workbook.add_format({'bold': True, 'bg_color': '#B7DEE8'})

        start_row = 0
        for estado in sorted(df['ESTADO'].unique()):
            estado_df = aba_df[aba_df['ESTADO'] == estado]
            estado_df = estado_df[estado_df['STATUS'].notna()]
            estado_df['STATUS'] = estado_df['STATUS'].astype(int)

            # Escreve título
            writer.sheets[sheet_name] = writer.book.add_worksheet(sheet_name)
            worksheet = writer.sheets[sheet_name]
            worksheet.write(start_row, 0, estado, workbook.add_format({'bold': True}))
            start_row += 1

            # Cabeçalho
            colunas = ['Réplica', 'Réplica Ativa', 'TOTAL', 'Total Elegiveis'] + \
                      list(map(str, status_elegiveis)) + ['Total Não Eleg'] + \
                      list(map(str, status_nao_elegiveis)) + \
                      ['Tx. Elegível', 'Tx. Sucesso', 'Recusa Total', 'Recusa Agenda', 'Recusa Entrev', 'Virgens']
            for col_idx, col in enumerate(colunas):
                worksheet.write(start_row, col_idx, col, workbook.add_format({'bold': True}))
            start_row += 1

            # Réplicas
            for replica in range(1, num_replicas + 1):
                rep_df = estado_df[estado_df['REPLICA'] == replica]
                contagem = rep_df['STATUS'].value_counts().to_dict()
                linha = [replica]

                ativo = "SIM" if 20 in contagem else "NÃO"
                linha.append(ativo)

                elegiveis = sum(contagem.get(s, 0) for s in status_elegiveis)
                nao_elegiveis = sum(contagem.get(s, 0) for s in status_nao_elegiveis)
                virgens = contagem.get(0, 0) if ativo == "SIM" else total_por_replica
                total = elegiveis + nao_elegiveis + virgens

                # Ajuste do TOTAL para bater com o teórico
                diff = total_por_replica - total
                virgens += diff
                total = elegiveis + nao_elegiveis + virgens

                linha.extend([total, elegiveis])
                linha += [contagem.get(s, 0) for s in status_elegiveis]
                linha.append(nao_elegiveis)
                linha += [contagem.get(s, 0) for s in status_nao_elegiveis]

                # Cálculo de taxas
                try:
                    tx_elegivel = elegiveis / total
                    tx_sucesso = contagem.get(20, 0) / elegiveis if elegiveis else 0
                    tx_agenda = contagem.get(4, 0) / elegiveis if elegiveis else 0
                    tx_entrev = contagem.get(44, 0) / elegiveis if elegiveis else 0
                    tx_recusa = tx_agenda + tx_entrev
                except ZeroDivisionError:
                    tx_elegivel = tx_sucesso = tx_agenda = tx_entrev = tx_recusa = 0

                linha += [tx_elegivel, tx_sucesso, tx_recusa, tx_agenda, tx_entrev, virgens]

                for col_idx, val in enumerate(linha):
                    fmt = workbook.add_format({'num_format': '0.00%'}) if isinstance(val, float) and val <= 1 else None
                    worksheet.write(start_row, col_idx, val, fmt)
                start_row += 1

            # Linha em branco + subtotal
            start_row += 1

        # Ajustes de largura
        worksheet.set_column('A:Z', 12)

    writer.close()
    return output_path
